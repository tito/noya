TUIO SIMULATOR
--------------
Copyright (c) 2006 Martin Kaltenbrunner <mkalten@iua.upf.es>
Developed at the Music Technology Group, IUA/UPF, Barcelona

This software is part of reacTIVision, an open source fiducial
tracking framework based on computer vision. 

http://mtg.upf.es/reactable/


Introduction:
-------------
This Simulator can be used by application developers for
the design of  tangible user interfaces based on reacTIVision,
without the actual need of a real table/camera setup in an
earlier project phase.

The TUIOSimulator simulates a virtual table with tangibles.
It tracks the ID, position and orientation of virtual objects
on a virtual table surface. This data is sent via a network 
connection to any client application. It implements the TUIO protocol,
which is based on Open sound control. See the included PDF file for
more information on this protocol.


Application Start:
------------------
This application is based on the Java programming language.
It needs a Java Runtime Environement installed on your system
in order to function properly. See: http://java.sun.com/j2se/

You can start the application by double clicking TUIOSimulator.jar.
Alternativly you can call "java -jar TUIOSimulator.jar" from the command line.

The default TUIO host is 127.0.0.1 (localhost)
The default TUIO port is 3333.

If you want to send TUIO messages to an alternative host or port,
you can start the application with -host and -port command line options.


Handling:
---------
* Dragging objects onto the white table surface will make them visible
  for the "virtual sensor". An activated object is marked with a green frame.
  The corresponding object ID number is written onto the object surface.

* Shift-Dragging an object is equivalent to lifting an object from the surface.

* Right-Dragging an object rotates it.
  The black bar within the object indicates its current rotation angle. 

* Shift-Right-Dragging is changing the face of volumetric objects.
  Volumetric objects (e.g. cubes) are marked with a dot in their centre.

* Choosing "Reset" from the "File" menu, resets the Simulator to its original state. 

* Enabling "Verbos" in the "File" menu, will print TUIO events to the console. 


Session Configuration:
----------------------
* see resources/config.xml for an example
* generic object types:
  name, shape, colour, description
* the current object list:
  type, faces, position, angle

References:
-----------
This application uses the JavaOSC OpenSound Control library.
See http://www.mat.ucsb.edu/~c.ramakr/illposed/javaosc.html
for more information and the source code.
