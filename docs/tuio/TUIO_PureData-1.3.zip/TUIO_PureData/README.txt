TUIO PureData Client
--------------------
Copyright (c) 2006 Martin Kaltenbrunner <mkalten@iua.upf.es>
Developed at the Music Technology Group, IUA/UPF, Barcelona

This software is part of reacTIVision, an open source fiducial
tracking framework based on computer vision. 

http://reactivision.sourceforge.net/

Demo Patch:
-----------
This package contains a simple patch that receives and decodes
TUIO messages reveived from reacTIVision or the simulator.

The TuioClient object takes an alternative port number as 
an optional argument. The default TUIO port is 3333.

There are two outputs, the first one is sending all relevant
TUIO events such as addObject, updateObject and removeObject
as well as addCursor, updateCursor and removeCursor.
The second output sends simple bangs for each fully received
frame, and every second while no new messages are received, 
in order to indicate that the connection is still alive.

The list format of the messages received at the first output
are in analogy to the TUIO message format:

addObject session_id fiducial_id
updateObject session_id fiducial_id xpos ypos angle xspeed yspeed rspeed maccel raccel
removeObject session_id fiducial_id

addCursor session_id
updateCursor session_id xpos ypos xspeed yspeed maccel
removeCursor session_id


External Source Code:
---------------------
The TuioClient external comes with its full source code which can be
built under Windows, Mac OS X as well as all Linux or Unix flavors.
In order to compile the external for your platform, type "make"
folloed by "pd_linux", "Pd_darwin" or "pd_nt" depending on your platform.
For convenience the Windows and Mac OS X binaries are included.

Patch License:
--------------
Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files
(the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of the Software,
and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

Any person wishing to distribute modifications to the Software is
requested to send the modifications to the original developer so that
they can be incorporated into the canonical version.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

