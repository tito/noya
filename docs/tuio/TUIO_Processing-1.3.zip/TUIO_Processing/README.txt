TUIO PROCESSING CLIENT
----------------------
Copyright (c) 2006 Martin Kaltenbrunner <mkalten@iua.upf.es>
Developed at the Music Technology Group, IUA/UPF, Barcelona

This software is part of reacTIVision, an open source fiducial
tracking framework based on computer vision. 

http://mtg.upf.es/reactable/

Demo Sketch:
------------
This package contains a demo sketch and a library which allows to
receive TUIO messages from the reacTIVision engine.
The TuioDemo Sketch graphically displays the object state on the screen
You can use this demo freely as a starting point for the development 
of you own Processing Sketch implementing the TUIO protocol.
Please refer to the source code of the example and the following section.

Installation:
-------------
Copy the "tuio" folder to the "libraries" folder of your processing installation.
Copy the "TuioDemo" folder into the "sketches" folder of your processing installation.
Open and execute the "TuioDemo" sketch to receive messages from reacTIVision.

Application Programming Interface:
----------------------------------
First you  need to create an instance of TuioClient. This object 
is listening to TUIO messages on the specified port and generates
higher level messages based on the object events.

Your sketch needs to implement the following methods 
in order to receive messages:

* addTuiObject(Integer s_id, Integer f_id):
  this is called when an object is added to the scene
* removeTuiObject(Integer id, Integer s_id):
  this is called when an object is removed from the scene
* updateTuiObject(Integer s_id, Integer f_id, Float xpos, Float ypos, Float angle):
  the parameters of an object are updated
  these are the objec's id, current position and orientation
* addTuiCursor(Integer s_id):
  this is called when a cursor is added to the scene
* removeTuiCursor(Integer s_id):
  this is called when a cursor is removed from the scene
* updateTuiCursor(Integer s_id, Float xpos, Float ypos):
  the parameters of a cursor are updated
  these are the objec's id, current position and orientation
* refresh():
  this method is called after each bundle,
  use it to repaint your screen for example

License:
--------
Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files
(the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of the Software,
and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

Any person wishing to distribute modifications to the Software is
requested to send the modifications to the original developer so that
they can be incorporated into the canonical version.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

References:
-----------
This library uses the JavaOSC OpenSound Control library.
See http://www.mat.ucsb.edu/~c.ramakr/illposed/javaosc.html
for more information and the source code.
