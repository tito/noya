/*  portVideo, a cross platform camera framework
    Copyright (C) 2005-2008 Martin Kaltenbrunner <mkalten@iua.upf.edu>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef NDEBUG

#include "FolderCamera.h"
#ifdef WIN32
#include <windows.h>
#endif 

FolderCamera::FolderCamera(const char* cfg): CameraEngine(cfg)
{
	cameraID = -1;
	
	buffer = NULL;
	sprintf(cameraName,"FolderCamera");

	running=false;
}

FolderCamera::~FolderCamera()
{
	if (buffer!=NULL) delete []buffer;
}

bool FolderCamera::findCamera() {
	readSettings();
	if (config.folder==NULL) return false;
	struct stat info;
	if (stat(config.folder,&info)!=0) return false;	
	return true;
}

bool FolderCamera::initCamera() {	

	int gray = 0;
	char header[32];
	char file_name[256];
	char *param;

#ifdef WIN32
	WIN32_FIND_DATA results;
	char buf[255];
    sprintf(buf, "%s\\*", config.folder);
	HANDLE list = FindFirstFile(buf, &results);
	while (FindNextFile(list, &results)) {
		if (strstr(results.cFileName,".pgm")!=NULL) {
			sprintf(file_name,".\recording\%s",results.cFileName);
			image_list.push_back(file_name);
		}
		
	}
	FindClose(list);
#else
	DIR *dp;
	struct dirent *ep;
	dp = opendir (config.folder);
	if (dp != NULL) {
		while ((ep = readdir (dp))) {
			 if (strstr(ep->d_name,".pgm")!=NULL) {
				sprintf(file_name,"./recording/%s",ep->d_name);
				image_list.push_back(file_name);
			  }
		}
		(void) closedir (dp);
	} else return false;
#endif

 	FILE*  imagefile=fopen(image_list.begin()->c_str(),"r");
	if (imagefile==NULL) return false;
		
	fgets(header,32,imagefile);
	while (strstr(header,"#")!=NULL) fgets(header,32,imagefile);
	if (strstr(header,"P5")==NULL) return false;
		
	fgets(header,32,imagefile);
	while (strstr(header,"#")!=NULL) fgets(header,32,imagefile);
	param = strtok(header," "); if (param) width = atoi(param);
	param = strtok(NULL," "); if (param) height =  atoi(param);
	param = strtok(NULL," "); if (param) gray = atoi(param);

	if (height==0) 	{ 
		fgets(header,32,imagefile);
		while (strstr(header,"#")!=NULL) fgets(header,32,imagefile);
		param = strtok(header," "); if (param) height = atoi(param);
		param = strtok(NULL," "); if (param) gray = atoi(param);
	}

	if (gray==0) {
		fgets(header,32,imagefile);
		while (strstr(header,"#")!=NULL) fgets(header,32,imagefile);
		param = strtok(header," "); if (param) gray = atoi(param);
	}

	if ((width==0) || (height==0) ) return false; 

	fclose(imagefile);

	config.width = width;
	config.height = height;
	bytes = 1;
	colour = false;
	fps = 50;
	
	buffer = new unsigned char[width*height*bytes];
	image_iterator = image_list.begin();
	return true;
}

unsigned char* FolderCamera::getFrame()
{
	int gray = 0;
	char header[32];
	char *param;

 	FILE*  imagefile=fopen(image_iterator->c_str(),"r");
	if (imagefile==NULL) return NULL;
		
	fgets(header,32,imagefile);
	while (strstr(header,"#")!=NULL) fgets(header,32,imagefile);
	if (strstr(header,"P5")==NULL) return NULL;
		
	fgets(header,32,imagefile);
	while (strstr(header,"#")!=NULL) fgets(header,32,imagefile);
	param = strtok(header," "); if (param) width = atoi(param);
	param = strtok(NULL," "); if (param) height =  atoi(param);
	param = strtok(NULL," "); if (param) gray = atoi(param);

	if (height==0) 	{ 
		fgets(header,32,imagefile);
		while (strstr(header,"#")!=NULL) fgets(header,32,imagefile);
		param = strtok(header," "); if (param) height = atoi(param);
		param = strtok(NULL," "); if (param) gray = atoi(param);
	}

	if (gray==0) {
		fgets(header,32,imagefile);
		while (strstr(header,"#")!=NULL) fgets(header,32,imagefile);
		param = strtok(header," "); if (param) gray = atoi(param);
	}

	if ((width!=config.width) || (height!=config.height) ) return NULL; 
	fread(buffer, bytes,  width*height, imagefile);
	fclose(imagefile);

	image_iterator++;
	if(image_iterator == image_list.end()) image_iterator=image_list.begin();


#ifdef WIN32
	Sleep(20);
#else 
	usleep( 20000 ); // simulate 50fps
#endif


	return buffer;	
}

bool FolderCamera::startCamera()
{
	running = true;
	return true;
}

bool FolderCamera::stopCamera()
{
	running = false;
	return true;
}

bool FolderCamera::stillRunning() {
	return running;
}

bool FolderCamera::resetCamera()
{
  return (stopCamera() && startCamera());
}

bool FolderCamera::closeCamera()
{
	return true;
}

bool FolderCamera::setCameraSettingAuto(int mode) {
	return false;
}

bool FolderCamera::setCameraSetting(int mode, int setting) {
	return false;
}

int FolderCamera::getCameraSetting(int mode) {
	return 0;
}

int FolderCamera::getMaxCameraSetting(int mode) {
	return 0;
}

int FolderCamera::getMinCameraSetting(int mode) {
	return 0;
}

void FolderCamera::showSettingsDialog() {
	return;
}
#endif

